from django.contrib import admin
from app.models import Task,Accounts
# Register your models here.
admin.site.register(Task)
admin.site.register(Accounts)